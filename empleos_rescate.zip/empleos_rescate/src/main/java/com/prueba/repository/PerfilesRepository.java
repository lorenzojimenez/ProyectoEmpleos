package com.prueba.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prueba.model.Perfil;








public interface PerfilesRepository extends JpaRepository<Perfil, Integer> {

}
