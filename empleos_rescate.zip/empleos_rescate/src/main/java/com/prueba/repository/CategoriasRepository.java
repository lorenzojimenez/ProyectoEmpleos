package com.prueba.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prueba.model.Categoria;






//public interface CategoriasRepository extends CrudRepository<Categoria, Integer> {}
public interface CategoriasRepository extends JpaRepository<Categoria, Integer> {

}
