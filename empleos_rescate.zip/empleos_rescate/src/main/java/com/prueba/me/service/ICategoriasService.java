package com.prueba.me.service;

import java.util.List;

import com.prueba.model.Categoria;


public interface ICategoriasService {
	void guardar(Categoria categoria);
	List<Categoria> buscarTodas();
	Categoria buscarPorId(Integer idCategoria);	
}
