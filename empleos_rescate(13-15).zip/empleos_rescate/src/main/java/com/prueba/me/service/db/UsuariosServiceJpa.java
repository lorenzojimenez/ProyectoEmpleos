package com.prueba.me.service.db;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.prueba.me.model.Usuario;
import com.prueba.me.repository.UsuariosRepository;
import com.prueba.me.service.IUsuariosService;

public class UsuariosServiceJpa implements IUsuariosService{

	@Autowired
	private UsuariosRepository usuariosRepo;
	
	@Override
	public void guardar(Usuario usuario) {
		usuariosRepo.save(usuario);
		
	}

	@Override
	public void eliminar(Integer idUsuario) {
		// TODO Auto-generated method stub
		usuariosRepo.deleteById(idUsuario);
	}

	@Override
	public List<Usuario> buscarTodas() {
		// TODO Auto-generated method stub
		return usuariosRepo.findAll();
	}

}
