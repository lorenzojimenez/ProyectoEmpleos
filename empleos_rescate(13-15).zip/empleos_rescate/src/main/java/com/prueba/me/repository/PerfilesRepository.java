package com.prueba.me.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prueba.me.model.Perfil;








public interface PerfilesRepository extends JpaRepository<Perfil, Integer> {

}
