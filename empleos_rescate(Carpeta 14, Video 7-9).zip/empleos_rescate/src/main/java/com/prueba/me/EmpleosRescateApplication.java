package com.prueba.me;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpleosRescateApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpleosRescateApplication.class, args);
	}

}
